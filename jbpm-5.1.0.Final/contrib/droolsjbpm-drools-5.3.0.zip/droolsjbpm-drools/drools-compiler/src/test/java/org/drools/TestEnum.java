package org.drools;

public enum TestEnum {
    
    ONE, TWO, THREE;

}
