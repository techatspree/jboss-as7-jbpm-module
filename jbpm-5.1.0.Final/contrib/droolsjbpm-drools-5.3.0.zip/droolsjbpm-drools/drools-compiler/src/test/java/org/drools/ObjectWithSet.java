package org.drools;

import java.util.Set;

public class ObjectWithSet
{
    private Set set;

    private String message;

    public String getMessage()
    {
        return message;
    }

    public void setMessage(String message)
    {
        this.message = message;
    }

    public ObjectWithSet()
    {
    }

    public Set getSet()
    {
        return set;
    }

    public void setSet(Set set)
    {
        this.set = set;
    }

}
