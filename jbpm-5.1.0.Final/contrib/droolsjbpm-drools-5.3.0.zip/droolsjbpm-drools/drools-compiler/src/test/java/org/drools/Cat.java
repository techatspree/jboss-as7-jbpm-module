package org.drools;

public class Cat extends Pet {

    public Cat(String ownerName) {
        super(ownerName);
    }

    public String getBreed() {
        return "Siamise";
    }
}
