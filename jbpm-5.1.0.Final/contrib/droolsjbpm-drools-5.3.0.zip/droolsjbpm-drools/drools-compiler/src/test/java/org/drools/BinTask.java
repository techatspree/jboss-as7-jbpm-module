package org.drools;

public class BinTask {
    private Bin bin;

    public Bin getBin() {
        return bin;
    }

    public void setBin(Bin bin) {
        this.bin = bin;
    }

}
