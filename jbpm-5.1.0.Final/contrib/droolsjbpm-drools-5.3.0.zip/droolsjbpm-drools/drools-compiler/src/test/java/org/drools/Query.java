package org.drools;

public class Query {
    public Query(String pattern, String column) {

    }
}
