package org.drools;

public final class PersonFinal extends Person {

}
