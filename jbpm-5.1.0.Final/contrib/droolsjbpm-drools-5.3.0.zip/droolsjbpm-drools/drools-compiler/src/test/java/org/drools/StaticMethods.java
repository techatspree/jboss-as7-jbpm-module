package org.drools;

public class StaticMethods {

    public static String getString1(final String string) {
        return string;
    }

    public static String getString2(final String string) {
        return string;
    }

}
