package org.drools;

public class Results {
    public int getResultsCount() {
        return 1;
    }
}
