package org.acme.healthcare;

public class Claim {

}
