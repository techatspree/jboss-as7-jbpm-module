package org.drools;

import java.io.Serializable;

public class Func implements Serializable {
    public static void func() {

    }

    public static void func(final String string) {

    }

    public static void func(final String x,
                            final String y) {

    }
}
