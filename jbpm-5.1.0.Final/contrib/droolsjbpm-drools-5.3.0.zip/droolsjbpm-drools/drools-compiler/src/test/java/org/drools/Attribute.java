package org.drools;

import java.io.Serializable;

public class Attribute implements Serializable
{

    public Integer getValue()
    {
        return null;
    }

}
