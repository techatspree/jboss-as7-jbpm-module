package org.drools;

public class RoutingMessage {
    private String routingValue;

    public String getRoutingValue() {
            return routingValue;
    }

    public void setRoutingValue(String routingValue) {
            this.routingValue = routingValue;
    }
}

