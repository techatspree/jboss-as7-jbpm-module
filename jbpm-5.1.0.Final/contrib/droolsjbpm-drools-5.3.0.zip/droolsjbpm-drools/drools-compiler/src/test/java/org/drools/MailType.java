package org.drools;

public enum MailType {
	WORK,
	HOME,
	OTHER;
}

