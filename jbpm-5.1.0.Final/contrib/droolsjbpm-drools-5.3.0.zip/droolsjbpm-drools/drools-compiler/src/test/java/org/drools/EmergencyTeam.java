package org.drools;

public class EmergencyTeam {
    public EmergencyTeam() {

    }
    
    public String toString() {
        return "[EmergencyTeam]";
    }
}