package org.drools;

public class Storage {
    public Results search(Query query) {
        return new Results();
    }
}
