package org.drools;

public class StaticMethods2 {
    public static String getString3(final String string,
                                    final Integer integer) {
        return string + integer;
    }
}
