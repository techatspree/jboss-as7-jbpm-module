package org.drools;

public class MockPersistentSetException extends RuntimeException
{
    public MockPersistentSetException(String message)
    {
        super(message);
    }
}
