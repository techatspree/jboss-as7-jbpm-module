package org.acme.sensors;

public class SensorReading {

}
