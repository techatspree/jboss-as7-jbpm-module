package org.drools.rule.builder;

public interface EnabledBuilder {
    public void build(final RuleBuildContext context);
}
