package org.drools.rule.builder;

/**
 * A markup interface for FromBuilders
 */
public interface FromBuilder extends RuleConditionBuilder {

}
