package org.drools.rule.builder;


public interface RuleClassBuilder {

    public String  buildRule(final RuleBuildContext context);

}