package org.drools.rule.builder;

/**
 * A markup interface for AccumulateBuilders
 */
public interface AccumulateBuilder extends RuleConditionBuilder {

}
