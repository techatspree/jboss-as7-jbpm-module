package org.drools.rule.builder.dialect.java.parser;

import java.util.ArrayList;
import java.util.List;

public class JavaRootBlockDescr extends AbstractJavaContainerBlockDescr 
    implements JavaContainerBlockDescr {

    public BlockType getType() {
        throw new UnsupportedOperationException();
    }

    public int getStart() {
        throw new UnsupportedOperationException();
    }

    public int getEnd() {
        throw new UnsupportedOperationException();
    }

    public String getTargetExpression() {
        throw new UnsupportedOperationException();
    }

    public void setTargetExpression(String str) {
        throw new UnsupportedOperationException();
    }

}
