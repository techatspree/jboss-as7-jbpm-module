package org.drools.rule.builder;

public interface SalienceBuilder {
    public void build(final RuleBuildContext context);
}
