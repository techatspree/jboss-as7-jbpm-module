package org.drools.rule.builder.dialect.java;

public class DialectSession {

}
