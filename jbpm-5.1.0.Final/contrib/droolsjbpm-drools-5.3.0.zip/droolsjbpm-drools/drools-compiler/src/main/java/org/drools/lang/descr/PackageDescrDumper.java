package org.drools.lang.descr;

public interface PackageDescrDumper {
    public String dump(final PackageDescr packageDescr);
}
