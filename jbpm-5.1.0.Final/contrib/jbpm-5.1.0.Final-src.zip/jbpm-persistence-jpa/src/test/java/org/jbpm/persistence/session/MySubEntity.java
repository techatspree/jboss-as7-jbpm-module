package org.jbpm.persistence.session;

import javax.persistence.Entity;

@Entity
public class MySubEntity extends MyEntity {

	private static final long serialVersionUID = 510l;
	
}
