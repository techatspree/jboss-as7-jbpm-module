package org.jbpm.persistence.session;

import javax.persistence.Entity;

@Entity
public class MySubEntityMethods extends MyEntityMethods {
	
	private static final long serialVersionUID = 510l;

}
